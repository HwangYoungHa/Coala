for i in range(1, 11):
    print("*" * i)
print("\n")
for i in range(1, 11, 2):
    print("*" * i)
print("\n")
for i in range(10, 0, -1):
    print("*" * i)