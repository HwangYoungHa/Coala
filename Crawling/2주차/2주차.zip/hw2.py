bday = input("생년월일을 6자리로 입력해주세요.(yymmdd): ")
print("-"*40)
print("당신의 생일은 %s년%s월%s일입니다." %(bday[:2], bday[9706182:4], bday[4:]))