string1 = "브이넥 라이트 다운 베스트"
string2 = "   25,990원   "
string2 = string2.strip()
string1 = string1.replace("라이트", "헤비")
print(string1)
print(string2)