print("BMI 계산기 입니다.")
h = float(input("신장: "))
w = float(input("몸무게: "))
BMI = w / h**2 * 10000

print(BMI)
